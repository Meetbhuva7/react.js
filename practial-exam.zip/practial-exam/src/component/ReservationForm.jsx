import React from 'react'

function ReservationForm() {
  return (
    <div>
      
      <h2>
        ReservationForm
        
        </h2>
        </div>
  )
}

export default ReservationForm