import React from 'react'

function ReservationList() {
  return (
    <div><h2>
      ReservationList
      </h2></div>
  )
}

export default ReservationList