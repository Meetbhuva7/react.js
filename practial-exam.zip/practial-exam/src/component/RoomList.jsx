import React from 'react'

function RoomList() {
  return (
    <div><h2>RoomList</h2></div>
  )
}

export default RoomList