import React from 'react'

function RoomDetail() {
  return (
    <div>
      <h2>RoomDetail</h2>
    </div>
  )
}

export default RoomDetail