export const Add=(payload)=>{
    return{
        type:"ADD",
        payload:payload
    }
}

export const Delete=(payload)=>{
    return{
        type:"DELETE",
        payload:payload
    }
}

export const Edit=(payload)=>{
    return{
        type:"EDIT",
        payload:payload
    }
}

